var APP_DATA = {
  "scenes": [
    {
      "id": "0-lobby",
      "name": "Lobby",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.817523463867155,
          "pitch": 0.20731067073075238,
          "rotation": 0,
          "target": "1-monitoring-room"
        },
        {
          "yaw": 1.3603069104252832,
          "pitch": 0.21550733902132535,
          "rotation": 0,
          "target": "1-monitoring-room"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-monitoring-room",
      "name": "Monitoring Room",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.5455002832728066,
          "pitch": 0.2079753383359737,
          "rotation": 0,
          "target": "2-meeting-rooom"
        },
        {
          "yaw": -1.5753956803834548,
          "pitch": 0.48427698966152377,
          "rotation": 0,
          "target": "0-lobby"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.5373400632822474,
          "pitch": 0.015929121363747356,
          "title": "Monitoring",
          "text": "<strong data-start=\"56\" data-end=\"79\">A monitoring system</strong> is a system or mechanism used to observe, track, and record the condition or performance of an object, process, or environment continuously or periodically."
        }
      ]
    },
    {
      "id": "2-meeting-rooom",
      "name": "Meeting Rooom",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.4946708087136411,
          "pitch": 0.16516801676170623,
          "rotation": 0,
          "target": "3-data-center"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-data-center",
      "name": "Data Center",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0.6593537655381247,
        "pitch": 0.20629062874210646,
        "fov": 1.6392879880227214
      },
      "linkHotspots": [
        {
          "yaw": 0.5980013250181351,
          "pitch": 0.06740000009625824,
          "rotation": 0,
          "target": "4-containment"
        },
        {
          "yaw": 1.637667298255293,
          "pitch": 0.018091363178729836,
          "rotation": 0,
          "target": "4-containment"
        },
        {
          "yaw": 0.10407037627008897,
          "pitch": 0.5942931165382213,
          "rotation": 0,
          "target": "1-monitoring-room"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.7884097846505291,
          "pitch": 0.029468848290811422,
          "title": "Containment",
          "text": "<strong data-start=\"55\" data-end=\"86\">Containment in server racks</strong> is a system used to manage and direct the flow of cooling air within a server room (data center) efficiently and in a controlled manner. The goal is to separate hot and cold air, ensuring stable temperatures and preventing equipment from overheating."
        },
        {
          "yaw": 1.3487253207089847,
          "pitch": 0.4611629316253474,
          "title": "Data Center",
          "text": "<strong data-start=\"70\" data-end=\"87\">A data center</strong> is a facility used to house computer systems and associated components, such as servers, storage systems, networking equipment, and power supplies. It is designed to store, process, and manage large amounts of data, and provides critical infrastructure for running applications, services, and IT operations."
        }
      ]
    },
    {
      "id": "4-containment",
      "name": "Containment",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 1.54356280923537,
          "pitch": 0.22210443052639128,
          "rotation": 0,
          "target": "3-data-center"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
